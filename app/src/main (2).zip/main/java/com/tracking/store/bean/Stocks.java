package com.tracking.store.bean;

/**
 * Created by ZASS on 3/22/2018.
 */

public class Stocks {
    public String Product;
    public Integer Qty;
    public boolean isStockAvaiable;
}
