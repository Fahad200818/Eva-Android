package com.tracking.store.util;

/**
 * Created by ZASS on 4/13/2018.
 */

public class Constants {
    public static final int GPS_SETTINGS_ACTIVITY_REQUEST_CODE  = 1111;
    public static String UserID = "UserID";
    public static String IsLogin = "IsLogin";
    public static String UserTockin = "UserTockin";
    public static String RemEmail = "RemEmail";
    public static String RemPass = "RemPass";
    public static String FullName = "FullName";
    public static String Email = "Email";
    public static String Filter = "Filter";
    public static String IS_SALE_USER = "IsSaleUser";
    public static String DISTRIBUTER_ID = "DistributerID";
}
