package com.tracking.store.bean;

/**
 * Created by ZASS on 4/10/2018.
 */

public class Point {
    public double latitude;
    public double longitude;
}