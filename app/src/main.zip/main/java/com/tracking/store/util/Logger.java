package com.tracking.store.util;

/**
 * Created by ZASS on 5/8/2018.
 */

public class Logger {
    private static final Logger ourInstance = new Logger();

    public static Logger getInstance() {
        return ourInstance;
    }

    
}
