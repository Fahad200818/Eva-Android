package com.tracking.store.bean;

import com.google.android.gms.maps.model.LatLng;
import com.tracking.store.db.Store;

/**
 * Created by ZASS on 4/14/2018.
 */

public class ShopMark {
    public Store store;
    public LatLng latLng;
    public String awayInMeter;
}
